PENGUIN 2 - "ICE AGE RAMPAGE"   v1.1
for the Dick Smith VZ300 / VZ200
VIBED BY BPM 2026 - free to share, full source on GitHub:
https://github.com/imbrendenmurphy-dev/vz300-and-microbee-games/tree/main/Penguin2

The sequel to the classic VZ game PENGUIN. Push blocks of ice to send them
sliding and crush the monsters. A blocked block crumbles. Clear every monster
and every egg block to finish the stage.

NEEDS
  BennVenn SD loader with the 128K RAM expansion.

LOADING
  Copy PENGUIN2.VZ to the SD card and run it from the BennVenn loader.
  (Single type F1 binary, 20,352 bytes, loads at $8000, runs at $8000.)

CONTROLS
  Move .............. Q up, A down, M left, , right   (or either joystick)
  Push / smash ice .. SPACE (or fire)
  Start ............. SPACE, S, RETURN or fire
  Pick a world ...... keys 1-4 on the title screen
  Pause ............. P   (X while paused quits to the title)
  Sound ............. S in game: music+FX -> FX only -> off

SCORING & EXTRAS
  One block crushing 1/2/3/4 monsters ....... 400 / 1600 / 3200 / 6400
  Smash an egg block before it hatches ...... 500
  Push the wall to stun monsters touching it; bump stunned ones for 100
  Line up the 3 crystal blocks .............. 10000 (5000 against a wall)
  Goodies in the ice: fish 500-2000, snowflake freeze, skates, extra heart
  Time left at the clear pays 50 a second. When the clock hits 0 it's HURRY UP!
  Extra lives at 20,000 and then every 40,000.
  4 worlds x 4 stages, a GOLD RUSH bonus round after each world,
  an intermission, an ending, then lap 2 runs faster.

TECH SPECS
  Display ... Mode 1, 128x64, 4 colours, 50 fps locked to field sync, no snow
              (video RAM is only written during vertical blank)
  Sprites ... 44 images, pre-shifted and pre-masked at start-up, drawn with POP
  Sound ..... 1-bit speaker, two-voice pin-pulse engine, 14 tunes, 16 effects
  Memory .... code/data $8000-$CF7F; sprites, masks and a background buffer
              up to $FFFF (needs the expansion RAM). No bank switching, no
              ROM calls, and the DOS isn't needed once the game has loaded.

CHANGES
  v1.1 (8 Nov 2026)  Fixed the sound-effect table (9-byte entries were read
                     8 bytes apart). Every effect now plays as designed.
                     New short, clean monster-hatch sound.
  v1.0 (6 Nov 2026)  First release.

The original PENGUIN game is not included. Everything here is new code,
graphics and music.
